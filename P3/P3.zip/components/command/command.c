#include "command.h"

void command_init()
{
	// ...
}

void command_receive(const lownet_frame_t* frame)
{
	// ...
}
